const router = require('express').Router();
const mongoose = require('mongoose');

const Schema = mongoose.Schema;

//connects to a mongoDB database, if it does not exist will create one
mongoose.connect('mongodb://localhost:27017/TDP_DB', { useNewUrlParser: true }, (err) => {
    if (err) return console.error(err);
    return console.log('Connection succesful');
});

const movies = require('../movies.js');

const movieSchema = new Schema ({
    name: {
        type: String,
        min: 2,
        required: true
    },
    description: {
        type: String,
        default: "N/A"
    },
    minsLength: {
        type: Number,
        min: 2,
        required: true
    }
});

//CREATE
router.post('/create', (req, res, next) => {
    const newMovie = req.body;
    movies.create(newMovie)
        .then((result) => res.status(201).send(result))
        .catch((err) => next(err));
});

//READ ALL
router.get('/read', (req, res) => {
    movies.find()
        .then((result) => res.send(result))
        .catch((err) => next(err));
});

//READ ONE
router.get('/read', (req, res) => {
    movies.find( {name: "Starship Troopers"} )
        .then((result) => res.send(result))
        .catch((err) => next(err));
});

//UPDATE
router.put('/update/:id', (req, res, next) => {
    const id = req.params.id;
    const newMovie = req.body;

    movies.findByIdAndUpdate(id, newMovie)
        .then((result) => res.send(result))
        .catch((err) => next(err));
});

//DELETE
router.delete('/delete/:id', (req, res, next) => {
    const id = req.params.id;

    movies.findByIdAndDelete(id)
        .then((result) => res.status(202).send(result))
        .catch((err) => next(err));
});

const movies = mongoose.model('movie', movieSchema);
module.exports = movies;