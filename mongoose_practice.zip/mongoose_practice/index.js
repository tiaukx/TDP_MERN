const express = require('express');
const app = express();

const movieRouter = require('./movies')
app.use('/movies', movies);

//error handling middleware
//must always have 4 variables - err, req, res, next
//as it is at the end of the file, nothing to pass to so no need to call next
app.use((err, req, res, next) => {
    res.status(err.status).send(err.message);
});