"use strict";

const output = document.getElementById('kittenOutput');


document.getElementById('kittenForm').addEventListener("submit", function (event) {
    event.preventDefault();

    const form = event.target;

    const kitten = {
        name: form.kittenName.value,
        age: form.kittenAge.value,
        breed: form.kittenBreed.value,
        cuteness: form.kittenCuteness.value
    }

    axios.post("http://localhost:4494/kitten/create", kitten)
        .then(res => {
            console.log(res);
            renderKittens();
        })
        .catch(err => console.error(err));

})



function renderKittens() {
    axios.get("http://localhost:4494/kitten/getAll")
        .then(res => {
            output.innerHTML = "";
            for (let kittens of res.data) {
                console.log(kittens);

                const kittenDiv = document.createElement("div");

                const kittenName = document.createElement("h2");
                kittenName.innerText = kittens.name;
                kittenDiv.appendChild(kittenName);

                const kittenAge = document.createElement("p");
                kittenAge.innerText = "Age: " + kittens.age;
                kittenDiv.appendChild(kittenAge);

                const kittenBreed = document.createElement("p");
                kittenBreed.innerText = "Breed: " + kittens.breed;
                kittenDiv.appendChild(kittenBreed);

                const kittenCuteness = document.createElement("p");
                kittenCuteness.innerText = "Cuteness: " + kittens.cuteness;
                kittenDiv.appendChild(kittenCuteness);

                output.prepend(kittenDiv);
            }
        })
        .catch(err => console.error(err));
}


renderKittens();