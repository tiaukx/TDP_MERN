"use strict";



fetch("https://raw.githubusercontent.com/ewomackQA/JSONDataRepo/master/example.json")
.then(res => res.json())
.then(data => {
    //grabbed the myData element and set the text inside of it as the JSON in string format
    document.getElementById('jsonData').innerText = JSON.stringify(data, null, 2);

})
.catch(err => console.error(err));


/*
axios.get("https://raw.githubusercontent.com/ewomackQA/JSONDataRepo/master/example.json")
    .then(response => console.log(response.data))
    .catch(err => console.error(err));*/
