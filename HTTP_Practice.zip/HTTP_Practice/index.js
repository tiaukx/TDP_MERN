"use strict";

/*
//Easiest way to do it
//Stringify turns JSON data into a string format
fetch("https://raw.githubusercontent.com/ewomackQA/JSONDataRepo/master/example.json")
.then(res => res.json())
.then(data => {
    //grabbed the myData element and set the text inside of it as the JSON in string format
    //third parameter adds spaces after everything
    document.getElementById('jsonData').innerText = JSON.stringify(data, null, 2);

})
.catch(err => console.error(err));
*/


//to format the json nicely:
const output = document.getElementById('jsonData');

fetch("https://raw.githubusercontent.com/ewomackQA/JSONDataRepo/master/example.json")
.then(response => response.json())
.then(res => {

    const heroes = res.data;
    console.log("HEROES: ", heroes);
    const squadName = document.createElement('h1');
    squadName.innerText = heroes.squadName;
    output.appendChild(squadName);

})
.catch(err => console.error(err));



/*
axios.get("https://raw.githubusercontent.com/ewomackQA/JSONDataRepo/master/example.json")
    .then(response => console.log(response.data))
    .catch(err => console.error(err));*/

