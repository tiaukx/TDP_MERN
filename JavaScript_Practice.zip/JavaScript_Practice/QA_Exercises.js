//Increases the value of a by 1 until it reaches 200 then terminates code execution
/*let a = 100;
while (a < 200) {
    a++;
    console.log(`a = ${a}`);
}*/

//Increases the value of a by 1 until it reaches 200 then terminates code execution
//If a is able to be divided by 2, output '-' else output '*'
/*let a = 100;
while (a < 200) {
    if (a % 2 == 0) {
        console.log("-")
    } else {
        console.log("*")
    }
    a++;
}*/


//Prints the numbers 1-10, 10 times
/*for (let i = 1; i <= 10; i++) {
    for (let j = 1; j <= 10; j++) {
        console.log(j);
    }
}*/

//1st Exercise but using for loops
/*for (let a = 100; a < 200; a++) {
    console.log(a);
}*/

//2nd Exercise but using for loops
/*for (let a = 100; a < 200; a++) {
    if (a % 2 == 0) {
        console.log("-")
    } else {
        console.log("*")
    }
}*/

//Write a switch case statement which uses the current day as its expression and matches with the relevant case
let now = new Date();
let day = now.getDay();

switch (day) {
    case 0:
        console.log(`It's Sunday`);
        break;
    case 6: 
        console.log(`It's Saturday`);
        break;
    case 1:
        console.log(`It's Monday`)
    case 2:
    case 3:
    case 4:
    case 5:
        console.log(`It's a weekday`);
        break;
    default:
        console.log(`Excuse me?`);
        break;    
}

let strictA = true;
let strictB = 1;
console.log(strictA == strictB); //Will return true as both are trutheys, only the values are checked
console.log(strictA === strictB); //Will return false using the strictly equaly operator as the type and the value are checked

console.log(strictA != strictB); //Will return false as type and values are not the same
console.log(strictA !== strictB); //Will return true as type and value were not the same anyway

let age = 26;

if (age > 18 && age < 65) {
    console.log("Between 18 & 65 years' old.")
} else if (age < 18) {
    console.log("Underage.")
} else {
    console.log("Over the age of 65.")
};


console.log(`Is the age over 50 years old? ${age > 50 ? "Yes" : "No"}`);