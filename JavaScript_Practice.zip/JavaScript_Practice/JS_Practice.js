//Variables
let helloWorld = "Hello World";

//Creates a pop-up window
//alert(helloWorld);
//Outputs to the console
console.log(helloWorld);
//Writes variable onto site page
document.write(helloWorld);

//Functions

//Accepts a number and returns it square
let numSquared = squaredFunction(8);
function squaredFunction (a) {
    return a ** 2;
};
console.log(numSquared);

//Accepts 3 numbers and returns the sum
let numSum = sumFunction(2, 2, 2);
function sumFunction(a, b, c) {
    return a + b + c;
}
console.log(numSum);

