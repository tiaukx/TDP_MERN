import './App.css';
import AddressApp from './address';
import Header from './Header';
import MyComponent from './MyComponent';
// import PropComp from './Props_practice';
import AnotherComponent from './Footer';

function App() {
  return (
    <div className="App">
      <Header/>
      <AddressApp/>
      <MyComponent/>
      {/* <PropComp/> */}
      <AnotherComponent/>
    </div>
  );
}

export default App;
