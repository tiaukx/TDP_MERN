const AnotherComponent = () => {
    return (
        <div>
            <p>This is the footer for the page.</p>
            <p>This is a 2nd p tag.</p>
            <p>This is a 3rd p tag.</p>
        </div>
    )
};

export default AnotherComponent;