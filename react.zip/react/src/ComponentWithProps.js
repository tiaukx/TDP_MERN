const ComponentWithProps = props => {
    return (
        <h1>{props.title}</h1>
        <p>{props.text}</p>
        <p>{props.numAndText}</p>
        <p>{props.someText}</p>
    )
}

const PropComp = () => {
    return (
        <>
            <ComponentWithProps title="Chris"/>
            <ComponentWithProps text="P."/>
            <ComponentWithProps numAndText="Bacon"/>
            <ComponentWithProps someText="Bacon"/>

        </>
    )
}

export default ComponentWithProps;