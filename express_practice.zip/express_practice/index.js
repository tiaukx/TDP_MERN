const express = require('express');
const app = express();

const bodyParser = require("body-parser");
app.use(bodyParser.json());

const server = app.listen(4494, () => {
    console.log("Server started on", server.address().port);
})

//log date to console then passes through next function
app.use((req, res, next) => {
    console.log("Date Accessed:", new Date());
    next();
});

//Sends a request to page that prints greeting + name
app.get("/hello", (req, res) => {
    res.send("Hello my name is Tia!");
});

//Creates array of names
let names = ['Tia', 'Moogle', 'Mickey', 'Jimmy'];

//Sends a request to print all names in array
app.get('/getAll', (req, res) => {
    res.send(names);
});

//Sends a request that prints name in array based on id
app.get('/getOne/:id', (req, res) => {
    res.send(names[req.params.id]);
});

//Removes name in array based on id in url, and prints name that has been removed
app.get('/remove/:id', (req, res) => {
    res.send(names.splice(req.params.id, 1));
});

//Pushes array created in postman to console log
app.post('/create', (req, res) => {
    console.log("Received:", req.body);
});


//Deletes an item in the array from postman
app.delete('/delete/:id', (req, res) => {
    const id = req.params.id;
    res.send(names.splice(req.params.id, 1));
    console.log("The following ID has been deleted", id);
});

//Adds a name from postman to array created in JS
app.post('/addName', (req, res) => {
    const name = req.body.name;
    names.push(name);
    res.status(201).send(`${name} added succesfully`);
});

//Adds multiple names from postman to array created in JS
app.post('/addNames', (req, res) => {
    const name = req.body;

    for (let person of name) {
        names.push(person.name);
    }

    res.status(201).send(`Names added succesfully`);
});

//Replaces a name in the array with a name specified in a query parameter at an index specified in a URL parameter
app.put('/updateName/:id', (req, res) => {
    //pulls through name from postman e.g. http://localhost:4494/updateName/0?name=Tiarnna
    //In the above URL, we are taking the id, which is 0, and the new name, which is Tiarnna
    const name = req.query.name;
    const id = req.params.id;

    //states old name from the JS array at the same id
    const old = names[id];
    //takes location of old name, and uses to update old name to new name from postman
    names[id] = name;
    //confirms that change has been made
    res.status(202).send(`${old} successfully replaced with ${name}`);
});

app.use((err, req, res, next) => {
    res.status(err.status).send(err.message);
});

