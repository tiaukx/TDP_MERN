const cows = require('./cow'); //imports the cow.js module

console.log(cows.speak('sup')); //uses the functions creates in cow.js to output text to console log