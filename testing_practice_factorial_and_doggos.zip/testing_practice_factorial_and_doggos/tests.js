const mocha = require('mocha');
const chai = require('chai');

const index = require('./index.js');
const doggos = require('./doggos.js');

//index.js testing
mocha.describe('Test factorial', () => {
    mocha.it('should equal 6!', () => {
        chai.expect(index.factorial(720)).to.equal('6!');
    });
    mocha.it('should equal 5!', () => {
        chai.expect(index.factorial(120)).to.equal('5!');
    });
    mocha.it('should equal none', () => {
        chai.expect(index.factorial(760)).to.equal('None');
    });
});

//doggos testing
mocha.describe('Test doggos', () => {
    mocha.it('should not show 5th place', () => {
        chai.expect().to.equal(doggos.showDogs(5));
    })
});